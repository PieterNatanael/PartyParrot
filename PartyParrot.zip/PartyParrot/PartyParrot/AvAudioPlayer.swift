//
//  AvAudioPlayer.swift
//  PartyParrot
//
//  Created by Pieter Yoshua Natanael on 26/08/23.
//

import Foundation
import AVFoundation


class AudioPlayerManager: ObservableObject {
    private var audioPlayer: AVAudioPlayer?

    init() {
        if let audioFilePath = Bundle.main.path(forResource: "music", ofType: "mp3") {
            let audioFileURL = URL(fileURLWithPath: audioFilePath)
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: audioFileURL)
            } catch {
                print("Error loading audio file: \(error.localizedDescription)")
            }
        }
    }

    func play() {
        audioPlayer?.play()
    }

    func pause() {
        audioPlayer?.pause()
    }
}
