//
//  ContentView.swift
//  PartyParrot
//
//  Created by Pieter Yoshua Natanael on 26/08/23.
//



import SwiftUI
import AVFoundation

struct ContentView: View {
    @ObservedObject private var audioPlayerManager = AudioPlayerManager()
    @State private var isButtonPressed = false

    var body: some View {
        VStack {
            if isButtonPressed {
                LottieView(loopMode: .loop)
                    .frame(height: 200)
                    .scaleEffect(0.4)
                
                Text("Party Bear")
                    .font(.title3)
                    .bold()
                    .padding()
            }

         

            Button(action: {
                audioPlayerManager.play()
                isButtonPressed = true
            }) {
                Text("Start")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.vertical, 12)
                    .padding(.horizontal, 20)
                    .background(Color.green)
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.3), radius: 8, x: 0, y: 4)
            }
            .padding()

            Button(action: {
                audioPlayerManager.pause()
                isButtonPressed = false // Hide the LottieView
            }) {
                Text("Pause")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.vertical, 12)
                    .padding(.horizontal, 20)
                    .background(Color.red)
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.3), radius: 8, x: 0, y: 4)
            }
            .padding()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

/*

import SwiftUI
import AVFoundation


struct ContentView: View {
    @ObservedObject private var audioPlayerManager = AudioPlayerManager()

    var body: some View {
        VStack {
            
            LottieView(loopMode: .loop)
                .frame(height: 200) // Set a fixed height for the LottieView
                .scaleEffect(0.4)
            
            Text("Party Parrot")
                .font(.title3)
                .bold()
                .padding()

            Button(action: {
                audioPlayerManager.play()
            }) {
                Text("Start")
                    .font(.system(size: 24, weight: .bold))
                          .foregroundColor(.white)
                          .padding(.vertical, 12)
                          .padding(.horizontal, 20)
                          .background(Color.green)
                          .cornerRadius(20)
                          .shadow(color: Color.black.opacity(0.3), radius: 8, x: 0, y: 4)
            }
            .padding()

            Button(action: {
                audioPlayerManager.pause()
            }) {
                Text("Pause")
                    .font(.system(size: 24, weight: .bold))
                          .foregroundColor(.white)
                          .padding(.vertical, 12)
                          .padding(.horizontal, 20)
                          .background(Color.red)
                          .cornerRadius(20)
                          .shadow(color: Color.black.opacity(0.3), radius: 8, x: 0, y: 4)
            }
            .padding()
        }
    }
}
 
 */

/*
@main
struct MusicApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
*/

/*
struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
*/
