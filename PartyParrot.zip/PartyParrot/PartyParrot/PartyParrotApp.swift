//
//  PartyParrotApp.swift
//  PartyParrot
//
//  Created by Pieter Yoshua Natanael on 26/08/23.
//

import SwiftUI
import AVFoundation


@main
struct PartyParrotApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
